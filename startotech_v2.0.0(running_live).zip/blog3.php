<!DOCTYPE html>
<html lang="en">
  <head>
    <title>STARTOTECH - Automation & Engineering Solutions</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/png" href="images/Logo/startotech.png"/>

    <script src="https://kit.fontawesome.com/495f11f58d.js" crossorigin="anonymous"></script>
     <?php 
        $ToEmail = 'sales@startotech.in'; 
        $EmailSubject = 'Request for subscription!'; 
        $mailheader = "From: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
        $MESSAGE_BODY .= "Email: ".$_POST["email"]."<br><br>";
        mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
    ?>
  </head>
  <body>
    <div class="py-1 bg-black top">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
          <div class="col-lg-12 d-block">
            <div class="row d-flex">
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-phone2"></span></div>
                <span class="text">+917009833930</span>
              </div>
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-paper-plane"></span></div>
                <span class="text">sales@startotech.in</span>
              </div>
              <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
                <p class="mb-0 register-link"><span>Open hours:</span> <span>Monday - Saturday</span>
                  <span>09:00AM - 09:00PM</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php"><img src="images/Logo/startotech.png" alt="statotech-icon"
					height="100px" width="110px" /></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="service.php" class="nav-link">Services</a></li>
	        	<li class="nav-item"><a href="menu.php" class="nav-link">Product</a></li>
	        	<li class="nav-item active"><a href="blog.php" class="nav-link">Blogs</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cta"><a href="request-for-quote.php" class="nav-link">Get A Quote</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('https://online.vidyaguru.in/wp-content/uploads/2017/08/blog-banner-1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Blog</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="blog.php">Blog <i class="ion-ios-arrow-forward"></i></a></span></p>
          </div>
        </div>
      </div>
    </section>
		
		<section class="ftco-section">
			<div class="container">
				<div class="row">
          <div class="col-lg-8 ftco-animate">
            <h2 class="mb-3">Solenoid Valve – Working process of solenoid valve</h2>
            <p>A solenoid valve is an electro-mechanical valve that can be used to control the flow of liquid or gas. The main components of the solenoid valves consist of a valve stem, valve disc, valve body, valve boot, valve seat, stop washer, centring washer, plunger, coil, and a cover nut. It is commonly used in hydraulics & pneumatics to shift two way and 3-way directional control valves and some pressure control valves. The basic function of the solenoid valve is to shut off, distribute, and release fluid.</p>
            <p>
              <img src="images/blog3.jpg" alt="" class="img-fluid">
            </p>
            <h4>Working process of the solenoid valves</h4>
            <p>The main functional components of solenoid valves are the coil, plunger, and sleeve assembly. When the orifice in the solenoid valve is open, then it allows the flow of fluid. However when it is closed, then it prevents the flow through the valve. To open the orifice of a solenoid valve plunger is used, which raises or lowers within the sleeve tube by energizing the coil. Once the solenoid coil is energized, the resultant magnetic field raises the plunger, enabling the flow. When the solenoid coil is energized in a normally open valve, the plunger seals off the orifice, which in turn prevents flow.</p>
            <h4>Application of Solenoid valves</h4>
            <ul>
              <li>Hydraulic action:- Solenoid valves are designed specifically for controlling hydraulic operations effectively.</li>
              <li>Controlling air pressure:- Solenoid valves are used for mixing and distributing the air effectively and hence, effectively control the air pressure.</li>
              <li>Treatment of water:- As it can purify the smallest particles and dust, they can be used effectively in the RO purifier as well.</li>
              <li>Fuel supply: – A solenoid valve is used in fuel valves to control the oil in vehicles. Highly efficient solenoid valves are leak-proof and can control the flow of oil effectively.</li>
              <li>Blood analysis instrument:- Solenoid valves are also used in blood analysis instruments. These instruments need to control the flow of the blood properly, and solenoid valves are designed specifically for this purpose.</li>
              <li>Machines and plant engineering:- Solenoid valves are commonly employed in manufacturing companies or oil refineries. They are often used to control the temperature of heater or furnace, firing systems, etc.</li>
            </ul>
            <h4>Features of Solenoid valves</h4>
            <p>It consists of a movable armature made of an iron alloy and attached to the valve needle, all sealed into the valve body. The coil is wound around the valve housing that contains the armature. The solenoid valve can be activated by a thermostat as well. Sare used to control the temperature of a refrigerator or a room.</p>
            <ul>
              <li>Full interchangeability of solenoid from AC to DC.</li>
              <li>Valves with Zero leaks.</li>
              <li>Valves with more than 20 million cycles.</li>
              <li>Clear flow paths give high Kv/Cv ratings.</li>
              <li>High efficient solenoid valves require less power to operate.</li>
            </ul>
            <h4>Benefits of using Solenoid valves</h4>
            <ul>
              <li>Solenoid valve has high flexibility due to modular design.</li>
              <li>With SKG you have a wide range of solenoid valves to choose.</li>
              <li>Our solenoid valve has high reliability and a long service life.</li>
              <li>Solenoid valve has a low environmental impact.</li>
            </ul>
            <p>Any requirement for the solenoid valve, feel free to contact us. We as SKG Pneumatics – distributor and suppliers of industrial valves provide a wide range of valves and fire fighting equipment from the best makers of the industry.</p>
            <div class="tag-widget post-tag-container mb-5 mt-5">
              <div class="tagcloud">
                <a href="blog1.php" class="tag-cloud-link">Blog-1</a>
                <a href="blog2.php" class="tag-cloud-link">Blog-2</a>
                <a href="blog3.php" class="tag-cloud-link">Blog-3</a>
              </div>
            </div>
            
            <!-- <div class="about-author d-flex p-4 bg-light">
              <div class="bio mr-5">
                <img src="images/person_1.jpg" alt="Image placeholder" class="img-fluid mb-4">
              </div>
              <div class="desc">
                <h3>George Washington</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus voluptate quod mollitia delectus aut, sunt placeat nam vero culpa sapiente consectetur similique, inventore eos fugit cupiditate numquam!</p>
              </div>
            </div> -->
          </div> 

          <div class="col-lg-4 sidebar ftco-animate">
            <div class="sidebar-box ftco-animate">
              <h3>Popular Articles</h3>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog1.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog1.php">The factory of the future:
                    people and machines
                    working together in harmony</a></h3>
                  <div class="meta">
                    <div><a href="blog1.php"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="blog1.php"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog2.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog2.php">Emergency Stop Control Stations: One Push Can Save Your Life</a></h3>
                  <div class="meta">
                    <div><a href="blog2.php"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="blog2.php"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog3.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog3.php">Solenoid Valve - Working process of solenoid valve</a></h3>
                  <div class="meta">
                    <div><a href="blog3.php"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="blog3.php"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- END COL -->
        </div>
			</div>
		</section>
		
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3 logo-icon">
            <img src="images/Logo/startotech.png" alt="statotech-icon" height="240px" width="250px"/>
            <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3 social-icon">
                <li class="ftco-animate"><a href="https://twitter.com/StartOtech?s=08" target="_blank"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/102235804841551/posts/102237928174672/" target="_blank"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://instagram.com/startotech?igshid=b2sxy64yqw5" target="_blank"><span class="icon-instagram"></span></a></li>
            </ul>
         </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p>STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means technical advancement. You can also understand it in terms of automation...<br/><a href="about.php" style="color: brown;">Read More...</a></p>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 sec">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Explore</h2>
              <ul class="list-unstyled open-hours">
                <li class="d-flex"><a href="index.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Home</span></a></li>
                <li class="d-flex"><a href="about.php"><i class="fas fa-chevron-right"></i><span class="recent-link">About</span></a></li>
                <li class="d-flex"><a href="service.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Services</span></a></li>
                <li class="d-flex"><a href="menu.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Product</span></a></li>
                <li class="d-flex"><a href="blog.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Blogs</span></a></li>
                <li class="d-flex"><a href="contact.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Contact</span></a></li>
              </ul>
            </div>
          </div>
         
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Newsletter</h2>
              <p>To get our latest news and updates regarding Products & Services.</p>
               <form class="subscribe-form"  method="post">
                    <div class="form-group">
                        <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Enter email address" required>
                    </div>
                     <div class="form-group">
                        <input type="submit" value="Send Message" class="form-control submit px-3">
                    </div>
                </form>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>