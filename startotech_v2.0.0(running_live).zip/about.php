<!DOCTYPE html>
<html lang="en">

<head>
  <title>STARTOTECH - Automation & Engineering Solutions</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.css">

  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">

  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/ionicons.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">


  <link rel="stylesheet" href="css/flaticon.css">
  <link rel="stylesheet" href="css/icomoon.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" type="image/png" href="images/Logo/startotech.png"/>
  <script src="https://kit.fontawesome.com/495f11f58d.js" crossorigin="anonymous"></script>
  
   <?php 
        $ToEmail = 'sales@startotech.in'; 
        $EmailSubject = 'Request for subscription!'; 
        $mailheader = "From: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
        $MESSAGE_BODY .= "Email: ".$_POST["email"]."<br><br>";
        mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
    ?>

</head>

<body>
  <div class="py-1 bg-black top">
    <div class="container">
      <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
        <div class="col-lg-12 d-block">
          <div class="row d-flex">
            <div class="col-md pr-4 d-flex topper align-items-center">
              <div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span>
              </div>
              <span class="text">+917009833930</span>
            </div>
            <div class="col-md pr-4 d-flex topper align-items-center">
              <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                  class="icon-paper-plane"></span></div>
              <span class="text">sales@startotech.in</span>
            </div>
            <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
              <p class="mb-0 register-link"><span>Open hours:</span> <span>Monday - Saturday</span> <span>09:00AM -
                  09:00PM</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
      <a class="navbar-brand" href="index.php"><img src="images/Logo/startotech.png" alt="statotech-icon"
          height="100px" width="110px" /></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
        aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
          <li class="nav-item active"><a href="about.php" class="nav-link">About</a></li>
          <li class="nav-item"><a href="service.php" class="nav-link">Services</a></li>
          <li class="nav-item"><a href="menu.php" class="nav-link">Product</a></li>
          <li class="nav-item"><a href="blog.php" class="nav-link">Blogs</a></li>
          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
          <li class="nav-item cta"><a href="request-for-quote.php" class="nav-link">Get A Quote</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- END nav -->

  <section class="hero-wrap hero-wrap-2" style="background-image: url('images/about-us.jpg');"
    data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
      <div class="row no-gutters slider-text align-items-end justify-content-center">
        <div class="col-md-9 ftco-animate text-center mb-4">
          <h1 class="mb-2 bread">About</h1>
          <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i
                  class="ion-ios-arrow-forward"></i></a></span> <span>About <i class="ion-ios-arrow-forward"></i></span>
          </p>
        </div>
      </div>
    </div>
  </section>


  <section class="ftco-section ftco-wrap-about">
    <div class="container">
      <div class="row">
        <div class="col-md-7 d-flex">
          <div class="img img-1 mr-md-2" style="background-image: url(images/p1.jpg);"></div>
          <div class="img img-2 ml-md-2" style="background-image: url(images/p2.jpg);"></div>
        </div>
        <div class="col-md-5 wrap-about pt-5 pt-md-5 pb-md-3 ftco-animate">
          <div class="heading-section mb-4 my-5 my-md-0">
            <span class="subheading">About</span>
            <h2 class="mb-4">Organization</h2>
          </div>
          <p class="about-para">STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means
            technical advancement. You can also understand it in terms of automation i.e; technology by which a process
            or procedure is transformed from manual to automatic. So Startotech is nothing but automation. Today
            automation is spreading across India on large scale. Industrialization in India is on peak and now companies
            are demanding automation so that they can increase their production and reduce labor cost and improve
            product quality. Since competition is high everyone wants automation at some or every steps of production.
            So STARTOTECH is here to provide solution, consultancy, commissioning and automation in process and
            manufacturing industries, Special Purpose Machine for different industries like Cement, Pipeline,
            Production, Manufacturing, Agriculture, Pharmacy etc. Startotech in collaboration with partners also provide
            industrial fabrication works and turn key projects.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-section bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services v-card d-block">
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-text">OUR <br /> VISION</h3>
              <p class="h-para">To be the company best known for cutting edge automation and solutions.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services m-card d-block">
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-text">OUR <br /> MISSION</h3>
              <p class="h-para">To offer innovative, creative and quality automation and engineering solutions to Manufacturing and process 
                industries. We are also offering quality electrical and automation products to customers.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services va-card d-block">
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-text">OUR <br /> VALUE</h3>
              <p class="h-para">We are innovative and creative work for customer reliability and repeatability and always promise quality projects and unique solutions.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <footer class="ftco-footer ftco-bg-dark ftco-section">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-6 col-lg-3 logo-icon">
          <img src="images/Logo/startotech.png" alt="statotech-icon" height="240px" width="250px" />
          <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3 social-icon">
            <li class="ftco-animate"><a href="https://twitter.com/StartOtech?s=08" target="_blank"><span class="icon-twitter"></span></a></li>
            <li class="ftco-animate"><a href="https://www.facebook.com/102235804841551/posts/102237928174672/" target="_blank"><span class="icon-facebook"></span></a></li>
            <li class="ftco-animate"><a href="https://instagram.com/startotech?igshid=b2sxy64yqw5" target="_blank"><span class="icon-instagram"></span></a></li>
          </ul>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">About Us</h2>
            <p>STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means technical
              advancement. You can also understand it in terms of automation...<br /><a href="about.php"
                style="color: brown;">Read More...</a></p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 sec">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Explore</h2>
            <ul class="list-unstyled open-hours">
              <li class="d-flex"><a href="index.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Home</span></a></li>
              <li class="d-flex"><a href="about.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">About</span></a></li>
              <li class="d-flex"><a href="service.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Services</span></a></li>
              <li class="d-flex"><a href="menu.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Product</span></a></li>
              <li class="d-flex"><a href="blog.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Blogs</span></a></li>
              <li class="d-flex"><a href="contact.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Contact</span></a></li>
            </ul>
          </div>
        </div>

        <div class="col-md-6 col-lg-3">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Newsletter</h2>
            <p>To get our latest news and updates regarding Products & Service.</p>
            <form class="subscribe-form"  method="post">
                <div class="form-group">
                    <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Enter email address" required>
                </div>
                 <div class="form-group">
                    <input type="submit" value="Send Message" class="form-control submit px-3">
                </div>
            </form>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 text-center">

          <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;
            <script>document.write(new Date().getFullYear());</script> All rights reserved
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
          </p>
        </div>
      </div>
    </div>
  </footer>


  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
      <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
      <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
        stroke="#F96D00" /></svg></div>
        


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="js/main.js"></script>

</body>

</html>