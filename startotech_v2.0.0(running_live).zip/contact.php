<!DOCTYPE html> 
<html lang="en">
  <head>
     <title>STARTOTECH - Automation & Engineering Solutions</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="STARTOTECH - Automation & Engineering Solutions"> 
    <meta name="keywords" content="STARTOTECH, Automation, Engineering, Automation & Engineering Solutions, startotech, star, starto, tech, Innovation & Creativity, Innovation, Creativity, Start + 0 + Tech"> 
    <meta name="author" content="Karan Kumar">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/png" href="images/Logo/startotech.png"/>

    <script src="https://kit.fontawesome.com/495f11f58d.js" crossorigin="anonymous"></script>

   <?php 
        $ToEmail = 'sales@startotech.in'; 
        $EmailSubject = 'Customer Enquiry'; 
        $mailheader = "From: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
        $MESSAGE_BODY = "Name: ".$_POST["name"]."<br><br>"; 
        $MESSAGE_BODY .= "Company Name: ".$_POST["company_name"]."<br><br>";
        $MESSAGE_BODY .= "Phone: ".$_POST["mobile"]."<br><br>";
        $MESSAGE_BODY .= "Email: ".$_POST["email"]."<br><br>";
        $MESSAGE_BODY .= "Message: ".nl2br($_POST["message"]).""; 
        mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
    ?>


  </head>
  <body>
    <div class="py-1 bg-black top">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
          <div class="col-lg-12 d-block">
            <div class="row d-flex">
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-phone2"></span></div>
                <span class="text">+917009833930</span>
              </div>
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-paper-plane"></span></div>
                <span class="text">sales@startotech.in</span>
              </div>
              <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
                <p class="mb-0 register-link"><span>Open hours:</span> <span>Monday - Saturday</span>
                  <span>09:00AM - 09:00PM</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php"><img src="images/Logo/startotech.png" alt="statotech-icon"
					height="100px" width="110px" /></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="service.php" class="nav-link">Services</a></li>
	        	<li class="nav-item"><a href="menu.php" class="nav-link">Product</a></li>
	        	<li class="nav-item"><a href="blog.php" class="nav-link">Blogs</a></li>
	          <li class="nav-item active"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cta"><a href="request-for-quote.php" class="nav-link">Get A Quote</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/contact.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay contact-bg"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Contact</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Contact us <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		
		<section class="ftco-section ftco-no-pt ftco-no-pb contact-section">
			<div class="container">
				<div class="row d-flex align-items-stretch no-gutters">
					<div class="col-md-5 pt-5 px-2 pb-2 p-md-5 order-md-last">
						<h2 class="h4 mb-2 mb-md-5 font-weight-bold">Contact Us</h2>
						<form class="contact_form" method="post">
                              <div class="form-group">
                                <input name="name" type="text" class="form-control" placeholder="Your Name" required>
                              </div>
                              <div class="form-group">
                                <input name="company_name"  type="text" class="form-control" placeholder="Company Name" required>
                              </div>
                              <div class="form-group">
                                <input name="mobile"type="text" class="form-control" placeholder="Mobile No." required>
                              </div>
                              <div class="form-group">
                                <input type="email" class="form-control" name="email" aria-describedby="emailHelp" placeholder="Enter email" required>
                                <small id="emailHelp" class="form-text text-muted" >We'll never share your email with anyone else.</small>
                              </div>
                              <div class="form-group">
                                <textarea name="message" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
                              </div>
                              <div class="form-group">
                                <input type="submit" onclick="myFunction()" value="Send Message" class="btn btn-primary submit-btn py-3 px-5">
                              </div>
                        </form>
					</div>
					<div class="col-md-7">
            
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7004.869009751665!2d76.98617222544057!3d28.616736879696045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d0fe9cfd76aed%3A0x81ec869d97febc39!2sC%20Block%2C%20Najafgarh%20Extension%2C%20Najafgarh%2C%20Delhi%2C%20110043!5e0!3m2!1sen!2sin!4v1589698229663!5m2!1sen!2sin" width="100%" height="650" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            
					</div>
				</div>
			</div>
		</section>
		<section class="ftco-section contact-section">
      <div class="container">
        <div class="row d-flex contact-info">
          <div class="col-md-12 mb-4">
            <h2 class="h4 font-weight-bold">Contact Information</h2>
          </div>
          <div class="w-100"></div>
          <div class="col-md-3 d-flex">
          	<div class="dbox">
	            <p><span>Address:</span><br/><a>C-Block, Heera Park, Najafgarh, New Delhi - 110043</a></p>
            </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="dbox">
	            <p><span>Phone:</span><br/> <a href="tel://7009833930">+917009833930</a></p>
            </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="dbox">
	            <p><span>Email:</span> <br/> <a href="mailto:sales@startotech.in">sales@startotech.in</a></p>
            </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="dbox">
	            <p><span>Website:</span><br/> <a href="#">www.startotech.in</a></p>
            </div>
          </div>
        </div>
      </div>
    </section>
		
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3 logo-icon">
            <img src="images/Logo/startotech.png" alt="statotech-icon" height="240px" width="250px"/>
            <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3 social-icon">
                <li class="ftco-animate"><a href="https://twitter.com/StartOtech?s=08" target="_blank"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/102235804841551/posts/102237928174672/" target="_blank"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://instagram.com/startotech?igshid=b2sxy64yqw5" target="_blank"><span class="icon-instagram"></span></a></li>
            </ul>
         </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p>STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means technical advancement. You can also understand it in terms of automation...<br/><a href="about.php" style="color: brown;">Read More...</a></p>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 sec">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Explore</h2>
              <ul class="list-unstyled open-hours">
                <li class="d-flex"><a href="index.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Home</span></a></li>
                <li class="d-flex"><a href="about.php"><i class="fas fa-chevron-right"></i><span class="recent-link">About</span></a></li>
                <li class="d-flex"><a href="service.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Services</span></a></li>
                <li class="d-flex"><a href="menu.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Product</span></a></li>
                <li class="d-flex"><a href="blog.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Blogs</span></a></li>
                <li class="d-flex"><a href="contact.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Contact</span></a></li>
              </ul>
            </div>
          </div>
         
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Newsletter</h2>
              <p>To get our latest news and updates regarding Products & Services.</p>
                <form class="subscribe-form">
                    <div class="form-group">
                        <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Enter email address" required>
                    </div>
                     <div class="form-group">
                        <input type="submit" value="Send Message" class="form-control submit px-3">
                    </div>
                </form>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

    <script>
        function myFunction() {
            alert("Your Message has been successfully Sent");
        }
    </script>

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>