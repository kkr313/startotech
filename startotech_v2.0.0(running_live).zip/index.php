<!DOCTYPE html>
<html lang="en">

<head>
  <title>STARTOTECH - Automation & Engineering Solutions</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="STARTOTECH - Automation & Engineering Solutions"> 
  <meta name="keywords" content="STARTOTECH, Automation, Engineering, Automation & Engineering Solutions, startotech, star, starto, tech, Innovation & Creativity, Innovation, Creativity, Start + 0 + Tech"> 
  <meta name="author" content="Karan Kumar"> 

  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.css">

  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">

  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/ionicons.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">


  <link rel="stylesheet" href="css/flaticon.css">
  <link rel="stylesheet" href="css/icomoon.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" type="image/png" href="images/Logo/startotech.png"/>

  <script src="https://kit.fontawesome.com/495f11f58d.js" crossorigin="anonymous"></script>
  <?php 
        $ToEmail = 'sales@startotech.in'; 
        $EmailSubject = 'Request for subscription!'; 
        $mailheader = "From: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
        $MESSAGE_BODY .= "Email: ".$_POST["email"]."<br><br>";
        mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
    ?>
</head>

<body>
  <div class="py-1 bg-black top">
    <div class="container">
      <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
        <div class="col-lg-12 d-block">
          <div class="row d-flex">
            <div class="col-md pr-4 d-flex topper align-items-center">
              <div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span>
              </div>
              <span class="text">+917009833930</span>
            </div>
            <div class="col-md pr-4 d-flex topper align-items-center">
              <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                  class="icon-paper-plane"></span></div>
              <span class="text">sales@startotech.in</span>
            </div>
            <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
              <p class="mb-0 register-link"><span>Open hours:</span> <span>Monday - Saturday</span> <span>09:00AM -
                  09:00PM</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
      <a class="navbar-brand" href="index.php"><img src="images/Logo/startotech.png" alt="statotech-icon"
          height="100px" width="110px" /></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
        aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>

      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active"><a href="index.php" class="nav-link">Home</a></li>
          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
          <li class="nav-item"><a href="service.php" class="nav-link">Services</a></li>
          <li class="nav-item"><a href="menu.php" class="nav-link">Product</a></li>
          <li class="nav-item"><a href="blog.php" class="nav-link">Blogs</a></li>
          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
          <li class="nav-item cta"><a href="request-for-quote.php" class="nav-link">Get A Quote</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- END nav -->

  <section class="home-slider owl-carousel">
    <div class="slider-item" style="background-image: url(images/bg_2.jpg);">
      <div class="overlay"></div>
      <div class="container">
        <div class="row slider-text justify-content-center align-items-center"
          data-scrollax-parent="true">

          <div class="col-md-12 col-sm-12 text-center ftco-animate">
            <span class="subheading title">We believe in</span>
            <h1 class="mb-4 title-text">Innovation & Creativity</h1>
          </div>

        </div>
      </div>
    </div>

    <div class="slider-item" style="background-image: url(images/bgg_3.jpg);">
      <div class="overlay"></div>
      <div class="container">
        <div class="row slider-text justify-content-center align-items-center"
          data-scrollax-parent="true">

          <div class="col-md-12 col-sm-12 text-center ftco-animate">
            <span class="subheading title">We provide best</span>
            <h1 class="mb-4 title-text">Automation & Solution</h1>
          </div>

        </div>
      </div>
    </div>

    <div class="slider-item " style="background-image: url(images/bg_6.jpg);">
      <div class="overlay"></div>
      <div class="container">
        <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">

          <div class="col-md-12 col-sm-12 text-center ftco-animate">
            <span class="subheading title">We work for customer</span>
            <h1 class="mb-4 title-text">Reliability & Repeatability</h1>
          </div>

        </div>
      </div>
    </div>
  </section>

  <!-- <section class="ftco-section ftco-no-pt ftco-no-pb">
    	<div class="container-fluid">
    		<div class="row">
    			<div class="col-md-12">
    				<div class="featured">
    					<div class="row">
    						<div class="col-md-3">
    							<div class="featured-menus ftco-animate">
			              <div class="menu-imgs img" style="background-image: url(images/c1.jpg);"></div>
			              <div class="text text-center">
		                  <h3>Grilled Beef with potatoes</h3>
				              <p><span>Meat</span>, <span>Potatoes</span>, <span>Rice</span>, <span>Tomatoe</span></p>
			              </div>
			            </div>
    						</div>
    						<div class="col-md-3">
    							<div class="featured-menus ftco-animate">
			              <div class="menu-imgs img" style="background-image: url(images/c2.jpg);"></div>
			              <div class="text text-center">
		                  <h3>Grilled Beef with potatoes</h3>
				              <p><span>Meat</span>, <span>Potatoes</span>, <span>Rice</span>, <span>Tomatoe</span></p>
			              </div>
			            </div>
    						</div>
    						<div class="col-md-3">
    							<div class="featured-menus ftco-animate">
			              <div class="menu-imgs img" style="background-image: url(images/c3.jpg);"></div>
			              <div class="text text-center">
		                  <h3>Grilled Beef with potatoes</h3>
				              <p><span>Meat</span>, <span>Potatoes</span>, <span>Rice</span>, <span>Tomatoe</span></p>
			              </div>
			            </div>
    						</div>
    						<div class="col-md-3">
    							<div class="featured-menus ftco-animate">
			              <div class="menu-imgs img" style="background-image: url(images/c4.jpg);"></div>
			              <div class="text text-center">
		                  <h3>Grilled Beef with potatoes</h3>
				              <p><span>Meat</span>, <span>Potatoes</span>, <span>Rice</span>, <span>Tomatoe</span></p>
			              </div>
			            </div>
    						</div>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </section> -->


  <section class="ftco-section ftco-wrap-about">
    <div class="container">
      <div class="row">
        <div class="col-md-7 d-flex">
          <div class="img img-1 mr-md-2" style="background-image: url(images/p1.jpg);"></div>
          <div class="img img-2 ml-md-2" style="background-image: url(images/p2.jpg);"></div>
        </div>
        <div class="col-md-5 wrap-about pt-5 pt-md-5 pb-md-3 ftco-animate">
          <div class="heading-section mb-4 my-5 my-md-0">
            <span class="subheading">About</span>
            <h2 class="mb-4">Organization</h2>
          </div>
          <p class="about-para">STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means
            technical advancement. You can also understand it in terms of automation i.e; technology by which a process
            or procedure is transformed from manual to automatic.So Startotech is nothing but automation. Today
            automation is spreading across India on large scale... </p>
          <div class="btn-div">
            <a href="about.php"><button type="button" class="info-btn">Read More...</button></a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-section bg-light">
    <div class="container">
      <div class="row justify-content-center mb-5 pb-2">
        <div class="col-md-12 text-center heading-section ftco-animate">
          <span class="subheading">Services</span>
          <h2 class="mb-4">Services & Solution</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services d-block">
            <div class="icon d-flex justify-content-center align-items-center">
              <i class="fas fa-cogs i-des"></i>
            </div>
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-d">SPM (Special Purpose Machines)</h3>
              <p class="d-para">Special purpose machines are designed to perform some specific applications which can
                not be carried out using conventional machines. We conceptualize the system design understanding the
                customer needs with a collaborative approach and develop the machine...</p>
              <p><a href="service.php" class="btn btn-primary pr-btn detail-btn">Read More...</a></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services d-block">
            <div class="icon d-flex justify-content-center align-items-center">
              <i class="fas fa-tools i-des"></i>
            </div>
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-d">Industrial Automation</h3>
              <p class="d-para">Industrial automation is the use of control systems, such as computers or robots, and
                information technologies for handling different processes and machineries in an industry to replace a
                human being. It is the second step beyond mechanization in the scope...</p>
              <p><a href="service.php" class="btn btn-primary pr-btn detail-btn">Read More...</a></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services d-block">
            <div class="icon d-flex justify-content-center align-items-center">
              <i class="fab fa-steam-symbol i-des"></i>
            </div>
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-d">PLC SCADA Automation System</h3>
              <p class="d-para">SCADA Autmation systems used to automate various power systems used in numerous
                industries. It also details what the system is made up of, how they optimize performance in large-scale
                systems, and how these systems still poses a threat to a company resources...</p>
              <p><a href="service.php" class="btn btn-primary pr-btn detail-btn">Read More...</a></p>
            </div>
          </div>
        </div>

      </div>
      <div class="row second-row">
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services d-block">
            <div class="icon d-flex justify-content-center align-items-center">
              <i class="fab fa-whmcs i-des"></i>
            </div>
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-d">Industrial Fabrication Works</h3>
              <p class="d-para">Startotech in collaboration with Industrial Fabrication Companies provide top class
                fabrication to our customers. The company works with customers from the early stages of a project
                budgeting and design all the way to manufacturing and shipping the final product...</p>
              <p><a href="service.php" class="btn btn-primary pr-btn detail-btn">Read More...</a></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services d-block">
            <div class="icon d-flex justify-content-center align-items-center">
              <i class="fab fa-battle-net i-des"></i>
            </div>
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-d">Industrial Turnkey Projects</h3>
              <p class="d-para">One of the special modes of carrying out international business is a turnkey project. It
                is a contract under which a firm agrees to fully design, construct and equip a manufacturing, business
                service facility and project over to the purchaser operation for a remuneration...</p>
              <p><a href="service.php" class="btn btn-primary pr-btn detail-btn">Read More...</a></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
          <div class="media block-6 services d-block">
            <div class="icon d-flex justify-content-center align-items-center">
              <i class="fab fa-first-order-alt i-des"></i>
            </div>
            <div class="media-body p-2 mt-3">
              <h3 class="heading h-d">Grid Automation</h3>
              <p class="d-para">Grid Automation System is a programmable intelligent electronic device (IED) designed to
                simplify substation monitoring and upgrades while improving measurement visibility. It does what
                fixed-function devices on the market can’t do because the functionality...</p>
              <p><a href="service.php" class="btn btn-primary pr-btn detail-btn">Read More...</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-section">
    <div class="container">
      <div class="row no-gutters justify-content-center mb-5 pb-2">
        <div class="col-md-12 text-center heading-section ftco-animate">
          <span class="subheading">Supply</span>
          <h2 class="mb-4">Product</h2>
        </div>
      </div>
      <div class="row no-gutters d-flex align-items-stretch">
        <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
          <div class="menus d-sm-flex ftco-animate align-items-stretch">
            <div class="menu-img img" style="background-image: url(images/automation4.jpg);"></div>
            <div class="text d-flex align-items-center">
              <div>
                <div class="d-flex">
                  <div class="one-half">
                    <h3>Phoenix Contact Terminal Blocks</h3>
                  </div>
                  <div class="one-forth">
                    <!-- <span class="price">$29</span> -->
                  </div>
                </div>
                <p><span>Automation Products</span></p>
                <p><a href="menu.php" class="btn btn-primary pr-btn">Check More</a></p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
          <div class="menus d-sm-flex ftco-animate align-items-stretch">
            <div class="menu-img img" style="background-image: url(images/pne4.jpg);"></div>
            <div class="text d-flex align-items-center">
              <div>
                <div class="d-flex">
                  <div class="one-half">
                    <h3>Sub-Micro Valves</h3>
                  </div>
                  <div class="one-forth">
                    <!-- <span class="price">$29</span> -->
                  </div>
                </div>
                <p><span>Pneumatic Valves</span></p>
                <p><a href="menu.php" class="btn btn-primary pr-btn">Check More</a></p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
          <div class="menus d-sm-flex ftco-animate align-items-stretch">
            <div class="menu-img img order-md-last" style="background-image: url(images/solenoid/s12.jpg);"></div>
            <div class="text d-flex align-items-center">
              <div>
                <div class="d-flex">
                  <div class="one-half">
                    <h3>Vapour blocking valve (VBV)</h3>
                  </div>
                  <div class="one-forth">
                    <!-- <span class="price">$29</span> -->
                  </div>
                </div>
                <p><span>Solenoid Valves</span></p>
                <p><a href="menu.php" class="btn btn-primary pr-btn">Check More</a></p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
          <div class="menus d-sm-flex ftco-animate align-items-stretch">
            <div class="menu-img img order-md-last" style="background-image: url(images/automation8.jpg);"></div>
            <div class="text d-flex align-items-center">
              <div>
                <div class="d-flex">
                  <div class="one-half">
                    <h3>Counters And Timers</h3>
                  </div>
                  <div class="one-forth">
                    <!-- <span class="price">$29</span> -->
                  </div>
                </div>
                <p><span>Automation Products</span></p>
                <p><a href="menu.php" class="btn btn-primary pr-btn">Check More</a></p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
          <div class="menus d-sm-flex ftco-animate align-items-stretch">
            <div class="menu-img img" style="background-image: url(images/solenoid/s13.jpeg);"></div>
            <div class="text d-flex align-items-center">
              <div>
                <div class="d-flex">
                  <div class="one-half">
                    <h3>Purge control solenoid valve</h3>
                  </div>
                  <div class="one-forth">
                    <!-- <span class="price">$29</span> -->
                  </div>
                </div>
                <p><span>Solenoid Valves</span></p>
                <p><a href="menu.php" class="btn btn-primary pr-btn">Check More</a></p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
          <div class="menus d-sm-flex ftco-animate align-items-stretch">
            <div class="menu-img img" style="background-image: url(images/pne9.jpg);"></div>
            <div class="text d-flex align-items-center">
              <div>
                <div class="d-flex">
                  <div class="one-half">
                    <h3>6-Position Selector Valves</h3>
                  </div>
                  <div class="one-forth">
                    <!-- <span class="price">$29</span> -->
                  </div>
                </div>
                <p><span>Pneumatic Valves</span></p>
                <p><a href="menu.php" class="btn btn-primary pr-btn">Check More</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-section img" style="background-image: url(images/q2-bg.jpeg)"
    data-stellar-background-ratio="0.8">
    <div class="container">
      <div class="row d-flex">
        <div class="quotation">
          <h1 class="q-header">AUTOMATION SOLUTION</h1>
          <p class="q-content">We have maintained the finest design competency, a meticulous control over quality and a
            customer-centric business model. We understand the value of repeat business and keeping focus on our
            customer satisfied.</p>
          <hr class="q-line">
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-section bg-light">
    <div class="container">
      <div class="row justify-content-center mb-5">
        <div class="col-md-7 text-center heading-section ftco-animate">
          <span class="subheading">Blog</span>
          <h2 class="mb-4">Recent Posts</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 ftco-animate">
          <div class="blog-entry">
            <a href="blog1.php" class="block-20" style="background-image: url('images/blog1.jpg');">
            </a>
            <div class="text pt-3 pb-4 px-4">
              <div class="meta">
                <div><a href="blog1.php">May 17, 2020</a></div>
                <div><a href="blog1.php">Admin</a></div>
              </div>
              <h3 class="heading"><a href="blog1.php">The factory of the future:
                people and machines
                working together in harmony</a></h3>
              <p class="clearfix" style="text-align: justify;">
                <a href="blog1.php" class="float-left read">Read more...</a>
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4 ftco-animate">
          <div class="blog-entry">
            <a href="blog2.php" class="block-20" style="background-image: url('images/blog2.jpg');">
            </a>
            <div class="text pt-3 pb-4 px-4">
              <div class="meta">
                <div><a href="blog2.php">May 17, 2020</a></div>
                <div><a href="blog2.php">Admin</a></div>
              </div>
              <h3 class="heading"><a href="blog2.php">Emergency Stop Control Stations: One Push Can Save Your Life</a></h3>
              <p class="clearfix">
                <a href="blog2.php" class="float-left read">Read more...</a>
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4 ftco-animate">
          <div class="blog-entry">
            <a href="blog3.php" class="block-20" style="background-image: url('images/blog3.jpg');">
            </a>
            <div class="text pt-3 pb-4 px-4">
              <div class="meta">
                <div><a href="blog3.php">May 17, 2020</a></div>
                <div><a href="blog3.php">Admin</a></div>
              </div>
              <h3 class="heading"><a href="blog3.php">Solenoid Valve <br/> Working process of solenoid valve</a></h3>
              <p class="clearfix">
                <a href="blog3.php" class="float-left read">Read more...</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer class="ftco-footer ftco-bg-dark ftco-section">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-6 col-lg-3 logo-icon">
          <img src="images/Logo/startotech.png" alt="statotech-icon" height="240px" width="250px" />
            <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3 social-icon">
                <li class="ftco-animate"><a href="https://twitter.com/StartOtech?s=08" target="_blank"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/102235804841551/posts/102237928174672/" target="_blank"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://instagram.com/startotech?igshid=b2sxy64yqw5" target="_blank"><span class="icon-instagram"></span></a></li>
            </ul>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">About Us</h2>
            <p>STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means technical
              advancement. You can also understand it in terms of automation...<br /><a href="about.php"
                style="color: brown;">Read More...</a></p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 sec">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Explore</h2>
            <ul class="list-unstyled open-hours">
              <li class="d-flex"><a href="index.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Home</span></a></li>
              <li class="d-flex"><a href="about.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">About</span></a></li>
              <li class="d-flex"><a href="service.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Services</span></a></li>
              <li class="d-flex"><a href="menu.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Product</span></a></li>
              <li class="d-flex"><a href="blog.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Blogs</span></a></li>
              <li class="d-flex"><a href="contact.php"><i class="fas fa-chevron-right"></i><span
                    class="recent-link">Contact</span></a></li>
            </ul>
          </div>
        </div>

        <div class="col-md-6 col-lg-3">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Newsletter</h2>
            <p>To get our latest news and updates regarding Products & Services.</p>
            <form class="subscribe-form"  method="post">
                <div class="form-group">
                    <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Enter email address" required>
                </div>
                 <div class="form-group">
                    <input type="submit" value="Send Message" class="form-control submit px-3">
                </div>
            </form>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 text-center">

          <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;
            <script>document.write(new Date().getFullYear());</script> All rights reserved
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
          </p>
        </div>
      </div>
    </div>
  </footer>


  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
      <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
      <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
        stroke="#F96D00" /></svg></div>


  
  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

</body>

</html>