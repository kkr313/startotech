<!DOCTYPE html>
<html lang="en">
  <head>
     <title>STARTOTECH - Automation & Engineering Solutions</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/png" href="images/Logo/startotech.png"/>

    <script src="https://kit.fontawesome.com/495f11f58d.js" crossorigin="anonymous"></script>
    
     <?php 
        $ToEmail = 'sales@startotech.in'; 
        $EmailSubject = 'Request for subscription!'; 
        $mailheader = "From: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
        $MESSAGE_BODY .= "Email: ".$_POST["email"]."<br><br>";
        mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
    ?>
  </head>
  <body>
    <div class="py-1 bg-black top">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
          <div class="col-lg-12 d-block">
            <div class="row d-flex">
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-phone2"></span></div>
                <span class="text">+917009833930</span>
              </div>
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-paper-plane"></span></div>
                <span class="text">sales@startotech.in</span>
              </div>
              <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
                <p class="mb-0 register-link"><span>Open hours:</span> <span>Monday - Saturday</span>
                  <span>09:00AM - 09:00PM</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php"><img src="images/Logo/startotech.png" alt="statotech-icon"
					height="100px" width="110px" /></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
          aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="service.php" class="nav-link">Services</a></li>
	        	<li class="nav-item"><a href="menu.php" class="nav-link">Product</a></li>
	        	<li class="nav-item active"><a href="blog.php" class="nav-link">Blogs</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cta"><a href="request-for-quote.php" class="nav-link">Get A Quote</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/blog.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Blog</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Blogs<i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

	  <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <span class="subheading">Blog</span>
            <h2 class="mb-4">Recent Posts</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog1.php" class="block-20" style="background-image: url('images/blog1.jpg');">
              </a>
              <div class="text pt-3 pb-4 px-4">
                <div class="meta">
                  <div><a href="blog1.php">May 17, 2020</a></div>
                  <div><a href="blog1.php">Admin</a></div>
                </div>
                <h3 class="heading"><a href="blog1.php">The factory of the future:
                  people and machines
                  working together in harmony</a></h3>
                <p class="clearfix" style="text-align: justify;">
                  <a href="blog1.php" class="float-left read">Read more...</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog2.php" class="block-20" style="background-image: url('images/blog2.jpg');">
              </a>
              <div class="text pt-3 pb-4 px-4">
                <div class="meta">
                  <div><a href="blog2.php">May 17, 2020</a></div>
                  <div><a href="blog2.php">Admin</a></div>
                </div>
                <h3 class="heading"><a href="blog2.php">Emergency Stop Control Stations: One Push Can Save Your Life</a></h3>
                <p class="clearfix">
                  <a href="blog2.php" class="float-left read">Read more...</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blog3.php" class="block-20" style="background-image: url('images/blog3.jpg');">
              </a>
              <div class="text pt-3 pb-4 px-4">
                <div class="meta">
                  <div><a href="blog3.php">May 17, 2020</a></div>
                  <div><a href="blog3.php">Admin</a></div>
                </div>
                <h3 class="heading"><a href="blog3.php">Solenoid Valve <br/> Working process of solenoid valve</a></h3>
                <p class="clearfix">
                  <a href="blog3.php" class="float-left read">Read more...</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  
		
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3 logo-icon">
            <img src="images/Logo/startotech.png" alt="statotech-icon" height="240px" width="250px"/>
            <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3 social-icon">
                <li class="ftco-animate"><a href="https://twitter.com/StartOtech?s=08" target="_blank"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/102235804841551/posts/102237928174672/" target="_blank"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://instagram.com/startotech?igshid=b2sxy64yqw5" target="_blank"><span class="icon-instagram"></span></a></li>
            </ul>
         </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p>STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means technical advancement. You can also understand it in terms of automation...<br/><a href="about.php" style="color: brown;">Read More...</a></p>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 sec">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Explore</h2>
              <ul class="list-unstyled open-hours">
                <li class="d-flex"><a href="index.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Home</span></a></li>
                <li class="d-flex"><a href="about.php"><i class="fas fa-chevron-right"></i><span class="recent-link">About</span></a></li>
                <li class="d-flex"><a href="service.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Services</span></a></li>
                <li class="d-flex"><a href="menu.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Product</span></a></li>
                <li class="d-flex"><a href="blog.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Blogs</span></a></li>
                <li class="d-flex"><a href="contact.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Contact</span></a></li>
              </ul>
            </div>
          </div>
         
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Newsletter</h2>
              <p>To get our latest news and updates regarding Products & Services.</p>
               <form class="subscribe-form"  method="post">
                    <div class="form-group">
                        <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Enter email address" required>
                    </div>
                     <div class="form-group">
                        <input type="submit" value="Send Message" class="form-control submit px-3">
                    </div>
                </form>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>