<!DOCTYPE html>
<html lang="en">
  <head>
    <title>STARTOTECH - Automation & Engineering Solutions</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/png" href="images/Logo/startotech.png"/>

    <script src="https://kit.fontawesome.com/495f11f58d.js" crossorigin="anonymous"></script>
    
     <?php 
        $ToEmail = 'sales@startotech.in'; 
        $EmailSubject = 'Request for subscription!'; 
        $mailheader = "From: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
        $MESSAGE_BODY .= "Email: ".$_POST["email"]."<br><br>";
        mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
    ?>
  </head>
  <body>
    <div class="py-1 bg-black top">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
          <div class="col-lg-12 d-block">
            <div class="row d-flex">
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-phone2"></span></div>
                <span class="text">+917009833930</span>
              </div>
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-paper-plane"></span></div>
                <span class="text">sales@startotech.in</span>
              </div>
              <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
                <p class="mb-0 register-link"><span>Open hours:</span> <span>Monday - Saturday</span>
                  <span>09:00AM - 09:00PM</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php"><img src="images/Logo/startotech.png" alt="statotech-icon"
					height="100px" width="110px" /></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="service.php" class="nav-link">Services</a></li>
	        	<li class="nav-item"><a href="menu.php" class="nav-link">Product</a></li>
	        	<li class="nav-item active"><a href="blog.php" class="nav-link">Blogs</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cta"><a href="rrequest-for-quote.php" class="nav-link">Get A Quote</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/blog1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Blog</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="blog.php">Blog <i class="ion-ios-arrow-forward"></i></a></span></p>
          </div>
        </div>
      </div>
    </section>
		
		<section class="ftco-section">
			<div class="container">
				<div class="row">
          <div class="col-lg-8 ftco-animate">
            <h2 class="mb-3">The factory of the future: people and machines working together in harmony.</h2>
            <p>Automation and artificial intelligence (AI) are transforming the efficiency of industrial production, through stronger interactions between man and machine that can boost productivity. A new, promising model for ‘factory harmony’ is based on intelligent, integrated and interactive design for tomorrow's manufacturing processes.</p>
            <p>Many people still believe that man and robots can’t work well together – or they’re afraid that machines will eventually replace people. However, the co-existence of people and automated machines and robots is becoming increasingly common in manufacturing companies. Furthermore, digitalisation gives manufacturers an enormous choice of technologies for implementing the factory of the future. For instance, smart networking using AI can be used to convert manufacturing data into strategic information. It also enables the smooth integration of high-precision, high-speed robotics.</p>
            <h4>Intelligent, integrated and interactive production</h4>
            <p>The latest innovative production solutions will increase efficiency and flexibility, reduce costs and strengthen a company’s competitive edge. At Omron, we offer collaborative robot solutions that shows how technology can revolutionise the factory floor by promoting harmony between people and machines.</p>
            <p>Our robot automates applications traditionally carried out by people. It can be seamlessly integrated into an autonomous mobile robot and can enable the automation of complex tasks. One example is bin picking. The robot quickly sorts different articles and deposits them where they’re needed. A 3D camera locates the items and sends their co-ordinates to the robot, while the software, supported by AI algorithms, performs the advanced calculations required for optimised goods picking. Meanwhile, a mobile robot is responsible for transporting the goods.</p>
            <p>This efficient combination of different production processes forms the basis for flexible and reliable production and material handling. It also gives a foretaste of factory harmony, in which integrated, mobile and collaborative robots will work with people to ensure flexible manufacturing and customisation.</p>
            <h4>Automation and quality control</h4>
            <p>Changing consumer behaviour is forcing manufacturers to produce smaller quantities of more product variants. The factory of the future must therefore be able to convert production more rapidly, with smaller runs. The ultimate goal is to deliver personalised products from an agile and networked production line, in which automation is achieved by all devices, machines and solutions operating in an integrated way.</p>
            <p>Effective quality control is essential in all production and packaging lines. The early identification of defective products can save time and money, by avoiding costly product recalls, loss of production and possible damage to the brand’s reputation. Quality control is also vital in product packaging for food or medicines: an illegible barcode or wrong expiry date can cause the disposal of faultless products. Stricter legislation has prioritised the unambiguous labelling of all products.</p>
            <p>
              <img src="images/blog1-1.jpg" alt="" class="img-fluid">
            </p>
            <h4>Flexibility: the key to business success</h4>
            <p>As customer and business needs evolve, the flexibility of the factory floor is a key factor in efficient production. It depends on the mobility and adaptability of the robots used. By combining image processing, motion, control, functional safety and robotics in a single management system, production lines can be more easily adapted to short production runs and changing market requirements. The line layout can be quickly redesigned and the recognition pattern for quality control can be easily updated in the software.</p>
            <p>This ensures that different products or variants can be produced and packaged flawlessly. This system is future-proof, because it can be easily adapted to new regulations.</p>
            <h4>Conclusion</h4>
            <p>The networking of humans and machines not only boosts efficiency and flexibility; it also demonstrates how people and machines can work in harmony to revolutionise production through the use of artificial intelligence and robotics. This model of factory harmony is breaking new ground for the production methods of the future.</p>
            <p>
              <img src="images/blog2-1.jpg" alt="" class="img-fluid">
            </p>
            <div class="tag-widget post-tag-container mb-5 mt-5">
              <div class="tagcloud">
                <a href="blog1.php" class="tag-cloud-link">Blog-1</a>
                <a href="blog2.php" class="tag-cloud-link">Blog-2</a>
                <a href="blog3.php" class="tag-cloud-link">Blog-3</a>
              </div>
            </div>
            
            <!-- <div class="about-author d-flex p-4 bg-light">
              <div class="bio mr-5">
                <img src="images/person_1.jpg" alt="Image placeholder" class="img-fluid mb-4">
              </div>
              <div class="desc">
                <h3>George Washington</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus voluptate quod mollitia delectus aut, sunt placeat nam vero culpa sapiente consectetur similique, inventore eos fugit cupiditate numquam!</p>
              </div>
            </div> -->


            
          </div> 

          <div class="col-lg-4 sidebar ftco-animate">
            <div class="sidebar-box ftco-animate">
              <h3>Popular Articles</h3>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog1.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog1.php">The factory of the future:
                    people and machines
                    working together in harmony</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog2.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog2.php">Emergency Stop Control Stations: One Push Can Save Your Life</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog3.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog3.php">Solenoid Valve - Working process of solenoid valve</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- END COL -->
        </div>
			</div>
		</section>
		
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3 logo-icon">
            <img src="images/Logo/startotech.png" alt="statotech-icon" height="240px" width="250px"/>
            <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3 social-icon">
                <li class="ftco-animate"><a href="https://twitter.com/StartOtech?s=08" target="_blank"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/102235804841551/posts/102237928174672/" target="_blank"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://instagram.com/startotech?igshid=b2sxy64yqw5" target="_blank"><span class="icon-instagram"></span></a></li>
            </ul>
         </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p>STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means technical advancement. You can also understand it in terms of automation...<br/><a href="about.php" style="color: brown;">Read More...</a></p>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 sec">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Explore</h2>
              <ul class="list-unstyled open-hours">
                <li class="d-flex"><a href="index.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Home</span></a></li>
                <li class="d-flex"><a href="about.php"><i class="fas fa-chevron-right"></i><span class="recent-link">About</span></a></li>
                <li class="d-flex"><a href="service.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Services</span></a></li>
                <li class="d-flex"><a href="menu.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Product</span></a></li>
                <li class="d-flex"><a href="blog.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Blogs</span></a></li>
                <li class="d-flex"><a href="contact.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Contact</span></a></li>
              </ul>
            </div>
          </div>
         
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Newsletter</h2>
              <p>To get our latest news and updates regarding Products & Services.</p>
               <form class="subscribe-form"  method="post">
                    <div class="form-group">
                        <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Enter email address" required>
                    </div>
                     <div class="form-group">
                        <input type="submit" value="Send Message" class="form-control submit px-3">
                    </div>
                </form>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>