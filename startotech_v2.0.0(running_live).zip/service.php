<!DOCTYPE html>
<html lang="en">

<head>
    <title>STARTOTECH - Automation & Engineering Solutions</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">


    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/png" href="images/Logo/startotech.png"/>
    <script src="https://kit.fontawesome.com/495f11f58d.js" crossorigin="anonymous"></script>
     <?php 
        $ToEmail = 'sales@startotech.in'; 
        $EmailSubject = 'Request for subscription!'; 
        $mailheader = "From: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
        $MESSAGE_BODY .= "Email: ".$_POST["email"]."<br><br>";
        mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
    ?>
</head>

<body>
    <div class="py-1 bg-black top">
        <div class="container">
            <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
                <div class="col-lg-12 d-block">
                    <div class="row d-flex">
                        <div class="col-md pr-4 d-flex topper align-items-center">
                            <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                                    class="icon-phone2"></span></div>
                            <span class="text">+917009833930</span>
                        </div>
                        <div class="col-md pr-4 d-flex topper align-items-center">
                            <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                                    class="icon-paper-plane"></span></div>
                            <span class="text">sales@startotech.in</span>
                        </div>
                        <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
                            <p class="mb-0 register-link"><span>Open hours:</span> <span>Monday - Saturday</span>
                                <span>09:00AM - 09:00PM</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
        <div class="container">
            <a class="navbar-brand" href="index.php"><img src="images/Logo/startotech.png" alt="statotech-icon"
                    height="100px" width="110px" /></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
                aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="oi oi-menu"></span> Menu
            </button>

            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
                    <li class="nav-item active"><a href="service.php" class="nav-link">Services</a></li>
                    <li class="nav-item"><a href="menu.php" class="nav-link">Product</a></li>
                    <li class="nav-item"><a href="blog.php" class="nav-link">Blogs</a></li>
                    <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
                    <li class="nav-item cta"><a href="request-for-quote.php" class="nav-link">Get A Quote</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- END nav -->

    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/service.png')"
        data-stellar-background-ratio="0.5">
        <div class="overlay bg-col"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-end justify-content-center">
                <div class="col-md-9 ftco-animate text-center mb-4">
                    <h1 class="mb-2 bread">Services</h1>
                    <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Services<i class="ion-ios-arrow-forward"></i></span></p>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section bg-light">
        <div class="container">
            <div class="row justify-content-center mb-5 pb-2">
                <div class="col-md-12 text-center heading-section ftco-animate">
                    <span class="subheading">Services</span>
                    <h2 class="mb-4">Services & Solution</h2>
                </div>
            </div>
            <!-- Accordion -->
    <div class="container-fluid bg-gray" id="accordion-style-1">
        <div class="container">
            <section>
                <div class="row">
                    <div class="col-12 mx-auto">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            <i class="fa fa-info main" aria-hidden="true"></i><i class="fa fa-angle-double-right mr-3"></i>SPM (Special Purpose Machines)
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseOne" class="collapse show fade" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                             <img src="images/spm.jpg" width="40%" height="60%" style="float: left; margin-right: 10px; margin-bottom: 5px; border: 1px solid black; padding: 2px;">
                                            <div>
                                                <dl>
                                                    <dd class="dd">SPMs or Special Purpose Machines offer tremendous scope for high volume production at
                                                        low investment and at low cost of production when compared to CNC machines. SPM, Special
                                                        Purpose Machines is a high productivity machine, with specially designed tooling and
                                                        fixture, dedicated for mass producing the same component day in and day out. A judicious
                                                        combination of limit switches, sensors, logic controls, automatic job clamping etc is
                                                        the essence of a SPM. A well conceived Special Purpose Machine finds ways and means to
                                                        utilize the man and machine to the optimum.Our highly qualified team work on your given
                                                        specification and design most reliable and efficient machine for your process. We not
                                                        only committed to design the machine but we and our team will wholely responsible for
                                                        getting desired result for which machine is design. We have wide range of manufacturing
                                                        unit that led us to build quality machines in lower cost. Just you have to maintain
                                                        patience and trust on Startotech.</dd>
                                                </dl>
                                                <p>We specialize in providing designs for a wide array of applications, which include:</p>
                                                <div class="col-md-4 d-flex align-self-stretch" style="float: left;">
                                                    <ul>
                                                        <li>Specialized industrial machines</li>
                                                        <li>Processing and packaging equipment</li>
                                                        <li>Welding automation</li>
                                                        <li>Gantry pick and place systems</li>
                                                        <li>Automated test equipment</li>
                                                    </ul>
                                                </div>
                                                <div class="col-md-4 d-flex align-self-stretch" style="float: left;">
                                                    <ul>
                                                        <li>Tooling systems for casting and sheet metal</li>
                                                        <li>Specialized manufacturing equipment</li>
                                                        <li>Articulating arms</li>
                                                        <li>Part transfer chutess</li>
                                                        <li>Rapid prototyping</li>
                                                    </ul>
                                                </div>
                                                <div class="col-md-4 d-flex align-self-stretch" style="float: left;">
                                                    <ul>
                                                        <li>Our special purpose machine design services involve:</li>
                                                        <li>Conceptual design</li>
                                                        <li>Reverse engineering</li>
                                                        <li>Detailed drawing</li>
                            
                                                        <li>Legacy CAD conversionss</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link collapsed btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            <i class="fa fa-info main" aria-hidden="true"></i><i class="fa fa-angle-double-right mr-3"></i>Industrial Automation
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseTwo" class="collapse fade" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <img src="images/indust-auto.jpeg" width="40%" height="60%" style="float: left; margin-right: 10px; margin-bottom: 5px; border: 1px solid black; padding: 2px;"/>
                                            <div>
                                                <dl>
                                                    <dd class="dd">Due to the rapid advances in technology, all industrial processing systems, factories,
                                                        machinery, test facilities, etc. turned from mechanization to automation. A
                                                        mechanization system needs human intervention to operate the manual operated machinery.
                                                        As new and efficient control technologies evolved, computerized automation control is
                                                        being driven by the need for high accuracy, quality, precision and performance of
                                                        industrial processes.
                                                        Automation is a step beyond the mechanization which makes use of high control capability
                                                        devices for efficient manufacturing or production processes.
                                                    </dd>
                                                    <dt>What is Industrial Automation?</dt>
                                                    <dd class="dd">Industrial automation is the use of control devices such as PC/PLCs/PACs etc. to control
                                                        industrial processes and machinery by removing as much labor intervention as possible, and
                                                        replacing dangerous assembly operations with automated ones. Industrial automation is closely
                                                        linked to control engineering.Automation is a broad term applied to any mechanism that moves by
                                                        itself or is self dictated. The word ‘automation’ is derived from ancient Greek words of Auto
                                                        (means ‘self’) Matos (means ‘moving’). As compared with manual systems, automation systems
                                                        provide superior performance in terms of precision, power, and speed of operation.
                                                    </dd>
                                                    <dd class="dd">In industrial automation control, a wide number of process variables such as temperature, flow,
                                                        pressure, distance, and liquid levels can be sensed simultaneously. All these variables are
                                                        acquired, processed and controlled by complex microprocessor systems or PC based data processing
                                                        controllers.
                                                        Industrial automation is the use of computer and machinery aided systems to operate the various
                                                        industrial operations in a well-controlled manner. Depends on the operations involved, the
                                                        industrial automation systems are majorly classified into two types, namely process plant
                                                        automation and manufacturing automation.
                                                    </dd>
                                                    <dd class="dd">
                                                        In process industries, the product results from many chemical processes based on some raw materials. 
                                                        Some of the industries are pharmaceuticals, petrochemical, cement industry, paper industry, etc. 
                                                        Thus the overall process plant is automated to produce the high quality, more productive, 
                                                        high reliable control of the physical process variables.
                                                    </dd>
                                                    <dt>Manufacturing Automation System:</dt>
                                                    <dd class="dd">
                                                        The manufacturing industries make the product out of materials using machines/robotics.
                                                        Some of these manufacturing industries include textile and clothing, glass and ceramic,
                                                        food and beverages, paper making, etc. New trends in manufacturing systems have been
                                                        using automation systems at every stage such as material handling, machining,
                                                        assembling, inspection, and packaging. With the computer-aided control and industrial
                                                        robotic systems, manufacturing automation becomes very flexible and efficient.
                                                    </dd>
                                                </dl>
                                                <video class="video-style" autoplay loop>
                                                    <source src="images/indust-auto2.mp4" type="video/mp4">
                                                </video>
                                                <dd class="dd">
                                                    Our expert team will help you to modify or say automate your process or manufacturing 
                                                    process so that your productivity can increase and reduce labour cost. 
                                                    In this way we will help you to compete in industrial market.
                                                </dd>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link collapsed btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            <i class="fa fa-info main" aria-hidden="true"></i><i class="fa fa-angle-double-right mr-3"></i>PLC SCADA Automation System
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseThree" class="collapse fade" aria-labelledby="headingThree" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div>
                                            <dl>
                                                <dd class="dd">Startotech is Industrial Automation provider with expertise in Programmable Logic Controllers (PLC), Drives (VFD), 
                                                    and Human Machine Interfaces (HMI) as well as Supervisory Control And Data Acquisition (SCADA) products. 
                                                    We are vendor-neutral industrial engineering and automation solutions providers. Major brands of automation 
                                                    products are supported by Startotech.
                                                </dd>
                                                <dd class="dd">
                                                    We provide unique and easy to do automation solution to our customers. 
                                                    Our engineers sit together to get best solutions for your industrial problem and 
                                                    then we provide reliable solutions with complete training support.
                                                </dd>
                                                <dd class="dd">Whether you plan to modify, upgrade, troubleshoot your automation installation or you have a
                                                    completely new requirement, we can provide you with seamless support from product selection to basic
                                                    engineering, software development, commissioning and post commissioning support.
                                                </dd>
                                                <dd class="dd">We work closely with our customers to arrive at an optimum migration solution based on their need
                                                    and budget. We provide complete range of Services for PLC, HMI, SCADA and Drives based Automation
                                                    Systems.
                                                </dd>
                                                <dt>We also offer</dt>
                                                <ul>
                                                    <li>Complete manual for solution</li>
                                                    <li>Training to your operator</li>
                                                    <li>Free maintenance service as per company rule</li>
                                                    <li>Circuit drawings</li>
                                                </ul>
                                            </dl>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingFour">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link collapsed btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            <i class="fa fa-info main" aria-hidden="true"></i><i class="fa fa-angle-double-right mr-3"></i>Industrial Fabrication Works
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseFour" class="collapse fade" aria-labelledby="headingFour" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div>
                                            <dl>
                                                <dd class="dd">Startotech in collaboration with Industrial Fabrication Companies provide top class fabrication to our customers.
                                                     The company works with customers from the early stages of a project budgeting and design all the way to 
                                                     manufacturing and shipping the final product. All our associates have highly trained welders with 
                                                     extensive experience in metal fabrication. These companies are best in their works.
                                                </dd>
                                                <dt>Why Startotech?</dt>
                                                <dd class="dd">
                                                    Since we have top class,highly qualified engineering team that always provide low budget
                                                     ,best suited fabrication design to our customers. We have wide range of top class 
                                                     fabricators and thus we have wide range and flexible price option. 
                                                     In this we provide low budget and quality fabrition.
                                                </dd>
                                            </dl>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingFive">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link collapsed btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            <i class="fa fa-info main" aria-hidden="true"></i><i class="fa fa-angle-double-right mr-3"></i>Industrial Turnkey Projects
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseFive" class="collapse fade" aria-labelledby="headingFive" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <img src="images/tuney.jpeg" width="30%" height="50%" style="float: left; margin-right: 10px; margin-bottom: 5px; border: 1px solid black; padding: 2px;">
                                        <div>
                                            <dl>
                                                <dd class="dd">Are you looking for someone to do your industrial turnkey projects? Then you are on
                                                    right place. We are here with our engineering team and large numbers of contractors
                                                    ready to do help you. We know very well how to shape your project in best possible way
                                                    so that you will get maximum and high quality products. Our team will follow all the
                                                    standard procedure to achieve maximum efficiency. Since we have huge network of
                                                    contractors ,Startotech become able to provide low costing for projects to the
                                                    customers.
                                                </dd>
                                            </dl>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingSix">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link collapsed btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                            <i class="fa fa-info main" aria-hidden="true"></i><i class="fa fa-angle-double-right mr-3"></i>Grid Automation
                                        </button>
                                     </h5>
                                </div>
                                <div id="collapseSix" class="collapse fade" aria-labelledby="headingSix" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <dl>
                                            <dd>With ever-increasing efficiency and supply quality requirements. To meet these demands operators
                                                need to introduce automation throughout the entire network. </dd>
                                            <dd>Startotech from few months driving the development of advanced protection, supervision, control
                                                and management products and systems for the complete power delivery process. As a forerunner
                                                also in the development and manufacturing of primary equipment, Startotech with its partner is
                                                able to create the best integration between the primary and secondary distribution to move
                                                towards more efficient and reliable grids.</dd>
                                            <dd>Investing in distribution grid automation improves operational efficiency and the quality of the
                                                power network, safety for the personnel and extends the life cycle of earlier investments.</dd>
                                            <dt>Scope</dt>
                                            <dd>Automation throughout the entire network</dd>
                                            <dt>Product benefits</dt>
                                            <dd>Scalable solutions - from basic monitoring to advanced protection functionality</dd>
                                            <dd>Most advanced earth-fault detection and protection on the market</dd>
                                            <dd>Solutions available for both new and existing installations that meet the demands from all types
                                                of power distribution grids</dd>
                                            <dd>Ready-made solutions for integration of the secondary substation data to the SCADA or DMS system
                                            </dd>
                                        </dl>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>	
                </div>
            </section>
        </div>
    </div>
<!-- .// Accordion -->

     </div>    
     </section>  



    <footer class="ftco-footer ftco-bg-dark ftco-section">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-6 col-lg-3 logo-icon">
                    <img src="images/Logo/startotech.png" alt="statotech-icon" height="240px" width="250px" />
                    <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3 social-icon">
                        <li class="ftco-animate"><a href="https://twitter.com/StartOtech?s=08" target="_blank"><span class="icon-twitter"></span></a></li>
                        <li class="ftco-animate"><a href="https://www.facebook.com/102235804841551/posts/102237928174672/" target="_blank"><span class="icon-facebook"></span></a></li>
                        <li class="ftco-animate"><a href="https://instagram.com/startotech?igshid=b2sxy64yqw5" target="_blank"><span class="icon-instagram"></span></a></li>
                    </ul>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="ftco-footer-widget mb-4">
                        <h2 class="ftco-heading-2">About Us</h2>
                        <p>STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means
                            technical advancement. You can also understand it in terms of automation...<br /><a
                                href="about.php" style="color: brown;">Read More...</a></p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3 sec">
                    <div class="ftco-footer-widget mb-4">
                        <h2 class="ftco-heading-2">Explore</h2>
                        <ul class="list-unstyled open-hours">
                            <li class="d-flex"><a href="index.php"><i class="fas fa-chevron-right"></i><span
                                        class="recent-link">Home</span></a></li>
                            <li class="d-flex"><a href="about.php"><i class="fas fa-chevron-right"></i><span
                                        class="recent-link">About</span></a></li>
                            <li class="d-flex"><a href="service.php"><i class="fas fa-chevron-right"></i><span
                                        class="recent-link">Services</span></a></li>
                            <li class="d-flex"><a href="menu.php"><i class="fas fa-chevron-right"></i><span
                                        class="recent-link">Product</span></a></li>
                            <li class="d-flex"><a href="blog.php"><i class="fas fa-chevron-right"></i><span
                                        class="recent-link">Blogs</span></a></li>
                            <li class="d-flex"><a href="contact.php"><i class="fas fa-chevron-right"></i><span
                                        class="recent-link">Contact</span></a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3">
                    <div class="ftco-footer-widget mb-4">
                        <h2 class="ftco-heading-2">Newsletter</h2>
                        <p>To get our latest news and updates regarding Products & Services.</p>
                        <form class="subscribe-form"  method="post">
                            <div class="form-group">
                                <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Enter email address" required>
                            </div>
                             <div class="form-group">
                                <input type="submit" value="Send Message" class="form-control submit px-3">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center">

                    <p>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;
                        <script>document.write(new Date().getFullYear());</script> All rights reserved
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
                </div>
            </div>
        </div>
    </footer>


    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
                stroke="#F96D00" /></svg></div>


    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/jquery.timepicker.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>

</body>

</html>