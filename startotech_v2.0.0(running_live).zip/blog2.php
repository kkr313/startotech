<!DOCTYPE html>
<html lang="en">
  <head>
    <title>STARTOTECH - Automation & Engineering Solutions</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/png" href="images/Logo/startotech.png"/>

    <script src="https://kit.fontawesome.com/495f11f58d.js" crossorigin="anonymous"></script>
    
     <?php 
        $ToEmail = 'sales@startotech.in'; 
        $EmailSubject = 'Request for subscription!'; 
        $mailheader = "From: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Reply-To: ".$_POST["email"]."\r\n"; 
        $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
        $MESSAGE_BODY .= "Email: ".$_POST["email"]."<br><br>";
        mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
    ?>
  </head>
  <body>
    <div class="py-1 bg-black top">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
          <div class="col-lg-12 d-block">
            <div class="row d-flex">
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-phone2"></span></div>
                <span class="text">+917009833930</span>
              </div>
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span
                    class="icon-paper-plane"></span></div>
                <span class="text">sales@startotech.in</span>
              </div>
              <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
                <p class="mb-0 register-link"><span>Open hours:</span> <span>Monday - Saturday</span>
                  <span>09:00AM - 09:00PM</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php"><img src="images/Logo/startotech.png" alt="statotech-icon"
					height="100px" width="110px" /></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="service.php" class="nav-link">Services</a></li>
	        	<li class="nav-item"><a href="menu.php" class="nav-link">Product</a></li>
	        	<li class="nav-item active"><a href="blog.php" class="nav-link">Blogs</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cta"><a href="request-for-quote.php" class="nav-link">Get A Quote</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('https://online.vidyaguru.in/wp-content/uploads/2017/08/blog-banner-1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Blog</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="blog.php">Blog <i class="ion-ios-arrow-forward"></i></a></span></p>
          </div>
        </div>
      </div>
    </section>
		
		<section class="ftco-section">
			<div class="container">
				<div class="row">
          <div class="col-lg-8 ftco-animate">
            <h2 class="mb-3">Emergency Stop Control Stations: One Push Can Save Your Life.</h2>
            <p>Let’s take a minute to think about how far we have advanced with innovation and technology. It is truly amazing when you look at the devices and products we develop these days. From a simple small piece of wood with a spring-loaded thin u-shaped metal rod and an extremely simple trigger mechanism designed to reduce the rodent population, to extremely complex electronic devices we just can’t even imagine living without in today’s world.</p>
            <p>
              <img src="images/blog2-2.jpg" alt="" class="img-fluid">
            </p>
            <p>Through the years machines were improved with cover guards, shields, and designs requiring minimal operator access while in operation. However, one device became one of the most important devices for operator safety, the emergency stop pushbutton (a.k.a. e-stop).</p>
            <h4>The Emergency Stop Pushbutton</h4>
            <p>The emergency stop pushbutton is a very simple way to quickly and completely freeze machine operation to prevent injury to an operator or costly damage to the machine. If the machine becomes dangerously unstable or the machine operator finds him/herself in danger, a simple push of the Emergency Stop pushbutton stops the danger. Keep in mind that some machines are simple and safe enough or have enough moving parts that a simple shield can provide the safety required. However, machines that can pose danger to operators most times require a more thorough safety system to ensure protection of human lives and equipment.</p>
            <p>
              <img src="images/blog1-2.png" alt="" class="img-fluid">
            </p>
            <p>The best thing to do when trying to determine if you need an emergency stop for your machine or production line, or how many emergency stop stations are required and their locations, is to follow a few recommendations. Of course, one of the first things to do is to visit OSHA and any other applicable safety and standards websites that indicate any mandates, recommendations and requirements for your specific area or industry. This will ensure you meet all safety requirements that apply to your specific area.</p>
            <h4>Here are some things to keep in mind when deciding emergency stop needs:</h4>
            <ul>
              <li>Carefully inspect all areas of your machines and production lines to make clear assessments of areas where danger zones can be identified. This is preferably done by a safety expert or Engineer.</li>
              <li>When a risk area that can benefit from an Emergency Stop station is identified, ensure that the location of the Emergency stop station is easily accessible by an operator.</li>
              <li>perators must be able to quickly and effectively push the emergency stop pushbutton.</li>
              <li>Emergency stop stations should be clearly visible. They are commonly bright yellow stations with a red pushbutton operator, which makes them easy to identify. They should not be obstructed from clear view in any way.</li>
              <li>The emergency stop pushbutton should be tied to a control system that requires some type of system reset once the e-stop pushbutton itself is reset. This ensures that all safety covers and devices are in place and that resuming machine operation is safe.</li>
              <li>Use the Emergency Stop pushbutton as part of a lockout/tagout procedure for added safety.</li>
            </ul>
            <p>REMEMBER! These are just some recommendations. It is highly recommended to follow your local and national safety requirements for best possible safety of your employees and machinery.</p>
            <p>AutomationDirect offers a line of quality and robust emergency stop stations made by IDEM that are ideal to tie to your system and provide protection to your employees and machinery. They are designed with a special lid safety trip mechanism that opens the contacts if the station lid is removed. Various models are available from a simple pushbutton station to models with a pushbutton protection shroud that accepts a padlock for lockout/tagout procedures, and IP69K rated models that can be used for areas that require high-pressure washdowns.</p>
            <p>In addition, AutomationDirect offers a wide range of safety devices such as safety light curtains and various safety switches such as interlock, cable-pull, limit, magnetic and many others that provide additional protection for both people and machines.</p>
            <p>
              <img src="images/blog2.jpg" alt="" class="img-fluid">
            </p>
            <div class="tag-widget post-tag-container mb-5 mt-5">
              <div class="tagcloud">
                <a href="blog1.php" class="tag-cloud-link">Blog-1</a>
                <a href="blog2.php" class="tag-cloud-link">Blog-2</a>
                <a href="blog3.php" class="tag-cloud-link">Blog-3</a>
              </div>
            </div>
            
            <!-- <div class="about-author d-flex p-4 bg-light">
              <div class="bio mr-5">
                <img src="images/person_1.jpg" alt="Image placeholder" class="img-fluid mb-4">
              </div>
              <div class="desc">
                <h3>George Washington</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus voluptate quod mollitia delectus aut, sunt placeat nam vero culpa sapiente consectetur similique, inventore eos fugit cupiditate numquam!</p>
              </div>
            </div> -->


            
          </div> 

          <div class="col-lg-4 sidebar ftco-animate">
            <div class="sidebar-box ftco-animate">
              <h3>Popular Articles</h3>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog1.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog1.php">The factory of the future:
                    people and machines
                    working together in harmony</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog2.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog2.php">Emergency Stop Control Stations: One Push Can Save Your Life</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/blog3.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="blog3.php">Solenoid Valve - Working process of solenoid valve</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> May 17, 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- END COL -->
        </div>
			</div>
		</section>
		
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3 logo-icon">
            <img src="images/Logo/startotech.png" alt="statotech-icon" height="240px" width="250px"/>
            <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3 social-icon">
                <li class="ftco-animate"><a href="https://twitter.com/StartOtech?s=08" target="_blank"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/102235804841551/posts/102237928174672/" target="_blank"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://instagram.com/startotech?igshid=b2sxy64yqw5" target="_blank"><span class="icon-instagram"></span></a></li>
            </ul>
         </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p>STARTOTECH (Start + 0 + Tech.) means start from zero i.e; manual work to Tech. means technical advancement. You can also understand it in terms of automation...<br/><a href="about.php" style="color: brown;">Read More...</a></p>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 sec">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Explore</h2>
              <ul class="list-unstyled open-hours">
                <li class="d-flex"><a href="index.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Home</span></a></li>
                <li class="d-flex"><a href="about.php"><i class="fas fa-chevron-right"></i><span class="recent-link">About</span></a></li>
                <li class="d-flex"><a href="service.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Services</span></a></li>
                <li class="d-flex"><a href="menu.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Product</span></a></li>
                <li class="d-flex"><a href="blog.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Blogs</span></a></li>
                <li class="d-flex"><a href="contact.php"><i class="fas fa-chevron-right"></i><span class="recent-link">Contact</span></a></li>
              </ul>
            </div>
          </div>
         
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Newsletter</h2>
              <p>To get our latest news and updates regarding Products & Services.</p>
               <form class="subscribe-form"  method="post">
                    <div class="form-group">
                        <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Enter email address" required>
                    </div>
                     <div class="form-group">
                        <input type="submit" value="Send Message" class="form-control submit px-3">
                    </div>
                </form>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>